package dana9919.gles.base;

import java.nio.FloatBuffer;
import java.util.ArrayList;

import android.util.Log;

public class MeshInfo {
	public String strMeshName = "";
	public int iSubsets=0;//SUBSET�ĸ���
	public int enumRENDER_TECH = -1;
	public ArrayList<SubInfo> arrSubInfo = new ArrayList<SubInfo>();
	
	public ArrayList<Float> arrData = new ArrayList<Float>();
	public int iVertCount;
	
	public FBInfo	posInfo = null;
	
	public int GetSubIndex(String strSubName){
		for(int i=0; i<arrSubInfo.size(); i++){
			if((arrSubInfo.get(i).strSubsetName)==strSubName)
				return i;
		}//end for
		return -1;
	}//ef
	public SubInfo GetSubset(String strSubName){
		
		for(int i=0; i<arrSubInfo.size(); i++){
			if((arrSubInfo.get(i).strSubsetName).trim().equals(strSubName))
				return arrSubInfo.get(i);
		}//end for
		return null;
	}//ef
	
	public void PutPosFB(FloatBuffer fbuf)//stride ���������ˣ��Զ�
	{
		posInfo = new FBInfo();
		posInfo._fbuf = fbuf;
		posInfo._iStride = 3*4;
	}//ef
	
	public SubInfo GetSubset(int index){
		if(index< arrSubInfo.size()){
			return arrSubInfo.get(index);
		}else{
			Log.e("ERR", "in MeshInfo::GetSubset");
			return null;
		}
		
	}//ef
	/**
	 * ����MESH INFO�����һ�� ��Ⲣ�������MESH INFO
	 * @return �ܶ�����
	 */
	public void CommitMeshInfo(){
		//PutPosFB(G9Function.PushIntoFLoatBuffer(arrData));
		iSubsets = arrSubInfo.size();
		iVertCount = 0;
		for (int i=0; i<iSubsets; i++){
			//Log.d("iSubset", Integer.toString(iSubsets));
			int iSubVert = arrSubInfo.get(i).CommitSubInfo();
			if(iSubVert<0)
			{
				//�׳��쳣
				throw new RuntimeException("Mesh��subset������");
			}				
			iVertCount += iSubVert;
		}//end for
		//return iVertCount;
	}//ef
}//EC
