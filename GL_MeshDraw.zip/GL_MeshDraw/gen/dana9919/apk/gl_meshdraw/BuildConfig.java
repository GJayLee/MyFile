/** Automatically generated file. DO NOT MODIFY */
package dana9919.apk.gl_meshdraw;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}