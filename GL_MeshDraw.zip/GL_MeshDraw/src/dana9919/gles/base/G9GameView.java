package dana9919.gles.base;

import android.content.Context;
import android.opengl.GLSurfaceView;

public abstract class G9GameView extends GLSurfaceView{
	protected Context _context;

	public G9GameView(Context context){
		super(context);
		_context = context;
		this.setEGLContextClientVersion(2);
	}//ef constructor
	
	//����
	public abstract void InitModel();
	public abstract void InitCamera(int iWinWidth,int iWinHeight);
	
	
}//EC
