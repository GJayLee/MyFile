package MeshSimplification;

import java.util.ArrayList;

import android.util.Log;

import dana9919.gles.base.G9Function;

public class MeshSimply {
	public ArrayList<Vertex> vertexs = new ArrayList<Vertex>();
	public ArrayList<Vertex> newVertexs = new ArrayList<Vertex>();
	public ArrayList<Triangle> triangles = new ArrayList<Triangle>();
	public ArrayList<Float> arrData = new ArrayList<Float>();
	public ArrayList<Tridata> tridatas = new ArrayList<Tridata>();
	public int collapse_map[];
	public int permutation[];
	
	public MeshSimply(ArrayList<Vertex> ver, ArrayList<Tridata> tri) {
		// TODO Auto-generated constructor stub
		vertexs = ver;
		tridatas = tri;
		for(int i = 0;i < tri.size();i++){
			Log.d("MeshSimply", Integer.toString(tri.get(i).v[0]));
			Triangle triangle = new Triangle(vertexs.get(tri.get(i).v[0]),
					vertexs.get(tri.get(i).v[1]),
					vertexs.get(tri.get(i).v[2]));
			triangles.add(triangle);
		}
		Log.d("MeshSimply", "Success");
	}
	
	public float magnitude(float[] v){
		return (float)Math.sqrt(Math.pow(v[0], 2) + Math.pow(v[1], 2) + Math.pow(v[2], 2));
	}
	
	public float ComputeEdgeCollapseCost(Vertex u, Vertex v){
		//Log.d("Function","ComputeEdgeCollapseCost");
		int i;
		float uPos[] = new float[3];
		float vPos[] = new float[3];
		for(i = 0;i < 3;i++){
			uPos[i] = u.position.get(i);
			vPos[i] = v.position.get(i);
		}
		
		float uvEage[] = new float[3];
		G9Function.glV3Subtract(uvEage, vPos, uPos);
		float edgelength = magnitude(uvEage);
		float curvature = 0;
		ArrayList<Triangle> sides = new ArrayList<Triangle>();
		for(i = 0;i < u.face.size();i++){
			if(u.face.get(i).HasVertex(v)){
				sides.add(u.face.get(i));
			}
		}
		for(i = 0;i < u.face.size();i++){
			float mincurv = 1;
			for(int j = 0;j < sides.size();j++){
				float dotprod = G9Function.glV3Dot(u.face.get(i).normal, sides.get(j).normal);  
				mincurv = Math.min(mincurv, (1-dotprod)/2.0f);
			}
			curvature = Math.max(curvature, mincurv);
		}
//		DecimalFormat df = new DecimalFormat("#.00000000");
//		if(Float.parseFloat(df.format(edgelength * curvature)) < 1E-8){             //��ʱ�²���С���㱣������
//			return 0.0f;
//		}
//		else{
//			return Float.parseFloat(df.format(edgelength * curvature));
//		}
		return edgelength * curvature;
	}
	
	public void ComputeEdgeCostAtVertex(Vertex v){
		//Log.d("Function","ComputeEdgeCostAtVertex");
		if(v.neighbor.size() == 0){
			ArrayList<Float> tempVer = new ArrayList<Float>();
			tempVer.add(0.0f);
			tempVer.add(0.0f);
			tempVer.add(0.0f);
			//v.collapse = null;
			v.collapse = new Vertex(tempVer, -1);
			v.objdist = -0.01f;
			return ;
		}
		v.objdist = 1000000;
		v.collapse = null;
		
		for(int i = 0;i < v.neighbor.size();i++){
			float dist;
			dist = ComputeEdgeCollapseCost(v, v.neighbor.get(i));
			if(dist < v.objdist){
				v.collapse = v.neighbor.get(i);
				v.objdist = dist;
			}
		}
		//Log.d("vertex collapse", Float.toString(v.objdist) + "--" + Integer.toString(v.id) + "--" + Integer.toString(v.collapse.id));
	}
	
	public void ComputeAllEdgeCollapseCost(){
		Log.d("Function","ComputeAllEdgeCollapseCost");
		for(int i = 0;i < vertexs.size();i++){
			ComputeEdgeCostAtVertex(vertexs.get(i));
		}
		Log.d("Function","done ComputeAllEdgeCollapseCost");
	}
	
	public void Collapse(Vertex u, Vertex v){
		//Log.d("Function","Collapse");
		//if( v == null)
		if(v.collapse == null){
			vertexs.remove(u);
			return ;
		}
		int i,k;
		for(i = 0;i < vertexs.size();i++){
			if(vertexs.get(i).neighbor.contains(u)){
				vertexs.get(i).neighbor.remove(u);
			}
		}
		ArrayList<Vertex> tmp = new ArrayList<Vertex>();
		for(i = 0;i < u.neighbor.size();i++){
			tmp.add(u.neighbor.get(i));
			//Log.d("neighbour", Integer.toString(u.id) + "--" + Integer.toString(u.neighbor.get(i).id));
		}
		
		for(i = u.face.size()-1;i >= 0;i--){
			if(u.face.get(i).HasVertex(v)){
				u.face.remove(i);
			}
		}
		
		for(k = 0;k < vertexs.size();k++){
			for(i = vertexs.get(k).face.size()-1;i >= 0;i--){
				if(vertexs.get(k).face.get(i).HasVertex(u) && vertexs.get(k).face.get(i).HasVertex(v)){
					vertexs.get(k).face.remove(i);
				}
			}
		}
		
		for(i = u.face.size()-1;i >= 0;i--){
			u.face.get(i).ReplaceVertex(u, v);
		}
		
		vertexs.remove(u);
		for(i = 0;i < tmp.size();i++){
			//Log.d("neighbour", Integer.toString(tmp.get(i).id) + "--" + Integer.toString(tmp.get(i).neighbor.size()));
			ComputeEdgeCostAtVertex(tmp.get(i));
		}
	}
	
	public Vertex MinimumCostEdge() {
		Vertex mn = vertexs.get(0);
		
		for(int i = 0;i < vertexs.size();i++){
			if(vertexs.get(i).objdist < mn.objdist){
				mn = vertexs.get(i);
			}
		}
		Log.d("MinimumCostEdge", Float.toString(mn.objdist) + "--" +Integer.toString(mn.id));
		return mn;
	}
	
	public void ProgressiveMesh(){
		Log.d("Function","ProgressiveMesh");
		ComputeAllEdgeCollapseCost();
		for(int i = 0;i < vertexs.size();i++){
			newVertexs.add(vertexs.get(i));
//			Log.d("oldVertexs", Float.toString(newVertexs.get(i).position.get(0)));
//			Log.d("oldVertexs", Float.toString(newVertexs.get(i).position.get(1)));
//			Log.d("oldVertexs", Float.toString(newVertexs.get(i).position.get(2)));
		}
		collapse_map = new int[vertexs.size()];
		permutation = new int[vertexs.size()];
		while(vertexs.size() > 0){
			Vertex mn = MinimumCostEdge();
			permutation[mn.id] = vertexs.size() - 1;
			Log.d("permutation", Integer.toString(mn.id) + "--" +Integer.toString(permutation[mn.id]));
			collapse_map[vertexs.size()-1] = (mn.collapse.id != -1)?mn.collapse.id:-1;
			Collapse(mn, mn.collapse);
		}
		Log.d("Function","done collapse");
		for(int i = 0;i < collapse_map.length;i++){
			collapse_map[i] = (collapse_map[i] == -1)?0:permutation[collapse_map[i]];
			Log.d("collapse_map", Integer.toString(i) + "--" + Integer.toString(collapse_map[i]));
		}
		Log.d("Function","done ProgressiveMesh");
	}
	//��������е㲻̫����
	public void PermuteVertices(int[] per){
		Log.d("Function","PermuteVertices");
		Log.d("vertexs.size",Integer.toString(newVertexs.size()));
		ArrayList<Vertex> temp_List = new ArrayList<Vertex>();
		int i;
		for(i = 0;i < newVertexs.size();i++){
			temp_List.add(newVertexs.get(i)); 
		}
		for(i = 0;i < newVertexs.size();i++){
			newVertexs.set(per[i], temp_List.get(i));
		}
		for(i = 0;i < triangles.size();i++){
			for(int j = 0;j < 3;j++){
				//triangles.get(i).vers.set(j, newVertexs.get(per[triangles.get(i).vers.get(j).id]));  
				tridatas.get(i).v[j] = permutation[tridatas.get(i).v[j]];
			}
		}
		Log.d("Function","done PermuteVertices");
	}
	
	public int Map(int a, int mx){
		if(mx <= 0)
			return 0;
		while(a >= mx){
			a = collapse_map[a];                 //collapse_map�����⣬���³�����ѭ��
		}
		return a;
	}
	
	public void CommitSimplifyInfo(){
		Log.d("Function","CommitSimplifyInfo");
		ProgressiveMesh();
		PermuteVertices(permutation); 
		int i = 0;
		int render_num = (int)newVertexs.size()/4;                           
		Log.d("render_num", Integer.toString(render_num));
		for(i = 0;i < tridatas.size();i++){
			int p0 = Map(tridatas.get(i).v[0], render_num);     //�˴����е㲻̫����
			int p1 = Map(tridatas.get(i).v[1], render_num);
			int p2 = Map(tridatas.get(i).v[2], render_num);
			if(p0 == p1 || p0 == p2 || p1 == p2) continue;
			int j;
			for(j = 0;j < 3;j++){
				arrData.add(newVertexs.get(p0).position.get(j));
			}
			for(j = 0;j < 3;j++){
				arrData.add(newVertexs.get(p1).position.get(j));
			}
			for(j = 0;j < 3;j++){
				arrData.add(newVertexs.get(p2).position.get(j));
			}
		}
		Log.d("Function","done CommitSimplifyInfo");
	}

}
