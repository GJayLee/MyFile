package dana9919.apk.gl_meshdraw;


import android.opengl.Matrix;
import dana9919.gles.G9Camera;
import dana9919.gles.base.G9Function;

public class TestThread extends Thread{	
	static float[] _mxTempRX = new float[16];
	static float[] _mxTempRY = new float[16];
	static float[] _mxTemp = new float[16];//������ת����
	
//	static float[] _mxTempTransX = new float[16];
//	static float[] _mxTempTransY = new float[16];
//	static float[] _mxTempTransZ = new float[16];
//	static float[] _mxTempTrans = new float[16];    //�ϲ�ƽ�ƾ���
	
	protected  G9Camera _vcemera = null;
	public boolean bFlag = true;
	public float fXRotate = 0;//����X����ۼ��ƶ��� ��3ά�ռ䰴Y����ת�Ļ���
	public float fYRotate = 0;//����Y����ۼ��ƶ��� ��3ά�ռ䰴X����ת�Ļ���
	
	public float scaleFactor = 0;
//	public float tx = 0;
//	public float ty = 0;
	public int ifRotate = 0;
	public int ifScale = 0;
//	public int ifTranslate = 0;
	
	/**
	 * ����ʱ�����������
	 */	
	public TestThread(G9Camera vCamera) {
		_vcemera = vCamera;
	}//ef
	
	public void scaleModel(float[] pos, float factor){
		float temp;
		boolean zoomIn = false;
		if(factor < 0){
			zoomIn = true;
			factor = -factor;
		}
		else if(factor > 0){
			zoomIn = false;
		}
		//�����������ԭ���ֱ�߽���ƽ�ƣ��ȸ�������ʽ���ֱ�߷��̣���ͨ��ƽ��������ﵽ�Ŵ���С��Ч��
		temp = (float)(Math.pow(pos[0], 2) + Math.pow(pos[1], 2) + Math.pow(pos[2], 2));
		temp = factor / temp;
		temp = (float)Math.sqrt(temp);
		if(zoomIn){
			pos[0] = pos[0] - pos[0] * temp;
			pos[1] = pos[1] - pos[1] * temp;
			pos[2] = pos[2] - pos[2] * temp;
		}
		else if(!zoomIn){
			pos[0] = pos[0] + pos[0] * temp;
			pos[1] = pos[1] + pos[1] * temp;
			pos[2] = pos[2] + pos[2] * temp;
		}
//		pos[0] = pos[0] * temp;
//		pos[1] = pos[1] * temp;
//		pos[2] = pos[2] * temp;
	}
	
	@Override
	public void run() {
		while (bFlag) {
			//ȡ��ָ�ƶ��ľ��룬��� foffX foffY Ȼ��
			try {
				sleep(33);
			} catch (InterruptedException e) {
				// 
				e.printStackTrace();
			}

			synchronized (_vcemera) {
				if(ifRotate == 1){
					float[] v3UP = new float[3];_vcemera.GetUp(v3UP);
					float[] v3Right = new float[3];_vcemera.GetRight(v3Right);
					G9Function.glRotateAxis(_mxTempRX, fXRotate, v3UP);
					G9Function.glRotateAxis(_mxTempRY, fYRotate, v3Right);
					Matrix.multiplyMM(_mxTemp, 0,_mxTempRX,0,_mxTempRY,0);
					
					float[] v3Pos =new float[3]; 
					_vcemera.GetPosition(v3Pos);			
					G9Function.glV3Transform(v3Pos, _mxTemp);
					_vcemera.SetPosition(v3Pos);
					_vcemera.SetLookTarget(new float[]{0,0,0});
				}
				else if(ifScale == 1){
					//Log.d("ifRotate", "Scale");
					if(scaleFactor != 0){
						float[] v3Pos =new float[3]; 
						_vcemera.GetPosition(v3Pos);
						scaleModel(v3Pos, scaleFactor);
						_vcemera.SetPosition(v3Pos);
						_vcemera.SetLookTarget(new float[]{0,0,0});
					}
				}
//				else if(ifTranslate == 1){
//					float[] v3Pos =new float[3]; 
//					_vcemera.GetPosition(v3Pos);
//					v3Pos[0] = v3Pos[0] + tx;
//					v3Pos[1] = v3Pos[1] + ty;
//					_vcemera.SetPosition(v3Pos);
//					_vcemera.SetLookTarget(new float[]{0,0,0});
//				}
			}			
		}//end while
		//super.run();
	}//ef
}//EC
