package MeshSimplification;

import java.util.ArrayList;

public class Vertex {
	public ArrayList<Float> position = new ArrayList<Float>();      //�����λ��
	public ArrayList<Vertex> neighbor = new ArrayList<Vertex>();    //���ڵĶ���
	public ArrayList<Triangle> face = new ArrayList<Triangle>();    //�����Ӧ��������
	
	public int id;
	public float objdist;
	public Vertex collapse;
	
	public Vertex(ArrayList<Float> v, int _id) {
		// TODO Auto-generated constructor stub
		position = v;
		id = _id;
	}
	
	public void RemoveIfNonNeighbor(Vertex n){
		if(neighbor.contains(n) == false){
			return ;
		}
		for(int i = 0;i < face.size();i++){
			if(face.get(i).HasVertex(n))
				return ;
		}
		neighbor.remove(n);
	}

}
