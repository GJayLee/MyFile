package dana9919.apk.gl_meshdraw;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.util.FloatMath;
import android.util.Log;
import android.view.MotionEvent;
import dana9919.gles.G9Camera;
import dana9919.gles.G9Mesh;
import dana9919.gles.G9Model;
import dana9919.gles.G9Render;
import dana9919.gles.ModelCollection;
import dana9919.gles.base.G9ENUM;

import dana9919.gles.base.G9GameView;

public class MyGame0824 extends G9GameView{

	//------------------------------------------------����
	static final float ONE_DEGREE = 1.0f/180.0f;
	
	private static final int NONE = 0;// ��
	private static final int DRAG = 1;// ���µ�һ����
	private static final int ZOOM = 2;// ���µڶ�����
	
	/** ��Ļ�ϵ������ */
	private int mode = NONE;
	
	//------------------------------------------------Ԫ��
	G9Camera viewCamera = null;//�����ڻص�������
	G9Camera lightCamera = null;//�����ڻص�������
	G9Render render = null;	
	ModelCollection mc = null;
	//�����߳�
	TestThread td;
	float fXScreenPre = 0;
	float fYScreenPre = 0;
	
	float oldDist = 0;
	float deltaDist = 0;
	
	ProgressDialog m_pDialog;
	//------------------------------------------------����
	public MyGame0824(Context context) {
		super(context);
		
		m_pDialog = new ProgressDialog(context);
		m_pDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		m_pDialog.show();
		
		render = new G9Render(this);//����ֵ��ȥû��,RENDER�ﱣ����ǿ�ָ��
		this.setZOrderOnTop(true);
        this.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        this.getHolder().setFormat(PixelFormat.TRANSLUCENT);
		setRenderer(render);
		setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
	}//ef constructor

	//------------------------------------------------����
	@Override
	public void InitModel() {
		// ����ģ��
		//mcΪModelCollection���ʵ��
		//renderΪG9Render���ʵ��
		mc = new ModelCollection();
		G9Mesh mesh = new G9Mesh(this.getResources(), "library.obj");
		//������ɫ����
		mesh.SetRenderTech(G9ENUM.RENDER_TECH_G9PHONG);
		G9Model model = new G9Model(mesh);
		
		mc.AddModel(model);
		//�� mc װ��render��ȥ
		render.SetModeCollection(mc);
		Log.d("test", "breakPoint");
		m_pDialog.cancel();
		
	}//ef
	@Override
	public void InitCamera(int iWinWidth, int iWinHeight) {
		// ��ʼ�������
		viewCamera = new G9Camera(iWinWidth, iWinHeight, 10000, 0.8f);
		lightCamera = new G9Camera(100, 100, 1000.0f, 0.5f);
		
		//viewCamera.SetPosition(new float[]{0,1.0f,2.0f});   //xuejian.obj
		//viewCamera.SetPosition(new float[]{0,60.0f,100.0f});     //jian.obj
		//viewCamera.SetPosition(new float[]{0,1.0f,50.0f});     //newpp.obj
		//viewCamera.SetPosition(new float[]{0,1.0f,3000.0f});     //castle.obj
		viewCamera.SetPosition(new float[]{0,1.0f,700.0f});     //church.obj
		//viewCamera.SetPosition(new float[]{0,1.0f,7000.0f});     //test
		viewCamera.SetLookTarget(new float[]{0,0,0});
		
		lightCamera.SetPosition(new float[]{120,300,0});
		lightCamera.SetLookTarget(new float[]{0,0,0});
		render.SetCameras(viewCamera, lightCamera);
		
		//��һ�λ���
		//����thread��ʼҪ��һ��CAMERA��ȥ�����Ҳ��ܴ���ֵ��ȥ,����ֻ���������
		//����C++ָ��ָ���ָ��
		td = new TestThread(viewCamera);
		td.start();
		
	}//ef
	
	//������ָ����֮��ľ���
	public float spacing(MotionEvent event)
	{
		float x = event.getX(0) - event.getX(1);
		float y = event.getY(0) - event.getY(1);
		return FloatMath.sqrt(x * x + y * y);
	}
	
	//------------------------------------------------����
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// 
		switch (event.getAction() & MotionEvent.ACTION_MASK) {
		case MotionEvent.ACTION_DOWN:
			mode = DRAG;
			fXScreenPre = event.getX(0);
			fYScreenPre = event.getY(0);
			break;
		case MotionEvent.ACTION_UP:
			mode = NONE;
			td.fXRotate = 0.0f;
			td.fYRotate = 0.0f;
			break;
		case MotionEvent.ACTION_POINTER_UP:
			mode = NONE;
			td.ifRotate = 1;
			break;
		case MotionEvent.ACTION_POINTER_DOWN:
			mode = ZOOM;
			oldDist = spacing(event);
			deltaDist = oldDist;
			break;
		case MotionEvent.ACTION_MOVE:
			if(mode == DRAG){
				td.ifRotate = 1;
				td.ifScale = 0;
				float fXNow = event.getX(0);
				float fYNow = event.getY(0);
				float fXDelta = fXNow - fXScreenPre;
				float fYDelta = fYNow - fYScreenPre;
				fXScreenPre = fXNow;
				fYScreenPre = fYNow;
				td.fXRotate = -fXDelta*0.5f;
				td.fYRotate = -fYDelta*0.5f;
			}else if(mode == ZOOM){
				float newDist = spacing(event);
				if(newDist - deltaDist > 50 || newDist - deltaDist < -50){
					td.ifRotate = 0;
					td.ifScale = 1;
					
					//float newDist = spacing(event);
					//Log.d("newDist", Float.toString(newDist) + "--" + Float.toString(oldDist));
					if(newDist > oldDist){
						td.scaleFactor = -10f;
					}
					else if(newDist < oldDist){
						td.scaleFactor = 10f;
					}
					oldDist = newDist;
				}
				else {
					td.ifRotate = 0;
					td.ifScale = 0;
					
					float fXNow = event.getX(0);
					float fYNow = event.getY(0);
					float tx = fXNow - fXScreenPre;
					float ty = fYNow - fYScreenPre;
					Matrix.translateM(mc.GetMoelList().get(0).GetWorldMatrix(), 0, tx, -ty, 0);
					fXScreenPre = fXNow;
					fYScreenPre = fYNow;
				}
			}
			break;
			
		default:
			break;
		}
		
		return true;
	}
	//------------------------------------------------����

	

	 
		
	
}//EC
