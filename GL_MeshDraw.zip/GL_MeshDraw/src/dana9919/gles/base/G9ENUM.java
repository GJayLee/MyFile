package dana9919.gles.base;

public class G9ENUM {
	public final static int RENDER_TECH_ERROR = -1;
	public final static int RENDER_TECH_G9PHONG = 1;
	
	

}//EC
