package dana9919.gles.base;
 
public interface MeshDrawable {
	public MeshInfo GetMeshInfo();
}
