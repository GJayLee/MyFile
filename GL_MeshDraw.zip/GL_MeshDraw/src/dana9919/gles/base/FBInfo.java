package dana9919.gles.base;

import java.nio.FloatBuffer;

public class FBInfo {
	public FloatBuffer	_fbuf = null;
	public int 	_iStride = 0;//����,�ֽ���

}
