package dana9919.gles;


import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.StringTokenizer;

//import MeshSimplification.MeshSimply;
//import MeshSimplification.Tridata;
//import MeshSimplification.Vertex;
import android.content.res.Resources;
import android.os.Environment;
import android.util.Log;
import dana9919.gles.base.G9ENUM;
import dana9919.gles.base.G9Function;
import dana9919.gles.base.MeshDrawable;
import dana9919.gles.base.MeshInfo;
import dana9919.gles.base.SubInfo;

public class G9Mesh implements MeshDrawable{
	//------------------------------------------------����	
	//------------------------------------------------Ԫ��
	MeshInfo _info = null;
	String sdPath = Environment.getExternalStorageDirectory().getPath();
	//------------------------------------------------���죨���ṩ�޲ι��죩
	public G9Mesh(Resources resource,String strObjFileName) {
		// ���ļ����������񣬲������ _info ���������ܳ� ����ԭ���ϲ�Ӧ�ֳ�С����
		ArrayList<Float> arr_v = new ArrayList<Float>();//�����ٴ� pos ����Ԫ
		ArrayList<Float> arr_vt = new ArrayList<Float>();//�ٴ� texcoord ����Ԫ
		ArrayList<Float> arr_vn = new ArrayList<Float>();//�ٴ� normal ����Ԫ
//		ArrayList<Vertex> vertexs = new ArrayList<Vertex>();
//		ArrayList<Triangle> triangles = new ArrayList<Triangle>();
//		ArrayList<Tridata> tridatas = new ArrayList<Tridata>();
		
		try{
			FileInputStream fin = new FileInputStream(sdPath + "/AR Model/" + strObjFileName);
			InputStream ins = new BufferedInputStream(fin);
			//InputStream ins = resource.getAssets().open(strObjFileName) ;//ֻ�ṩinputstream�ķ���
			InputStreamReader inReader = new InputStreamReader(ins);
			BufferedReader br = new BufferedReader(inReader);
			String strTemp = null;//�ٴ�ÿ���ַ�			
			
			SubInfo  curSub = null;//��ǰ������SubInfo ��������ٴ�����;
			_info = new MeshInfo();
			
//			int k = 0;
			long startTime = Calendar.getInstance().getTimeInMillis();
			Log.d("LoadObjTime", "Start time " + startTime);
			
//			loadVt vtList = new loadVt(resource,strObjFileName);
//			vtList.run();
//			arr_vt = vtList.getArr_vt();
//			for(int i = 0;i < arr_vt.size();i++){
//				Log.d("arr_vt", Float.toString(arr_vt.get(i)));
//			}
//			loadVn vnList = new loadVn(br);
//			vnList.run();
//			arr_vn = vnList.getArr_vn();
			
			while((strTemp = br.readLine())!=null)//����Ҳ��Ϊnull
			{
				//ArrayList<Float> ver = new ArrayList<Float>();
				StringTokenizer parts = new StringTokenizer(strTemp, " ");
				int numTokens = parts.countTokens();
				if (numTokens == 0)
					continue;
				String type = parts.nextToken();
				if(type.equals("o"))//ȡ�ļ���
				{
					_info.strMeshName = parts.nextToken();
					continue;
				}else if(type.equals("mtllib") )//���������ļ�
				{
					//��mtl�ļ�,��ʼͼƬ(ʱ����sufaceview����֮��),������subset����
					String strMtlFilename = parts.nextToken(); 
					_info.iSubsets = SetupMaterial(resource,strMtlFilename);
					continue;
				}else if(type.equals( "v"))//POS����
				{
					float[] vPos = new float[3];
					vPos[0] = Float.parseFloat(parts.nextToken());
					vPos[1] = Float.parseFloat(parts.nextToken());
					vPos[2] = Float.parseFloat(parts.nextToken());
					arr_v.add(vPos[0]);
					arr_v.add(vPos[1]);
					arr_v.add(vPos[2]);
//					Log.d("vPos", Float.toString(vPos[0]));
//					Log.d("vPos", Float.toString(vPos[1]));
//					Log.d("vPos", Float.toString(vPos[2]));
					
					//����򻯼�¼�����б�
//					ver.add(vPos[0]);
//					ver.add(vPos[1]);
//					ver.add(vPos[2]);
//					vertexs.add(new Vertex(ver, k));     //�����б�
//					k++;
					continue;
				}
				else if(type.equals("vt"))//texcoord����
				{
					arr_vt.add(Float.parseFloat(parts.nextToken()));
					arr_vt.add(1.0f-Float.parseFloat(parts.nextToken()));
					continue;
				}
				else if(type.equals( "vn"))//normal ����
				{
					arr_vn.add(Float.parseFloat(parts.nextToken()));
					arr_vn.add(Float.parseFloat(parts.nextToken()));
					arr_vn.add(Float.parseFloat(parts.nextToken()));
					continue;
				}/////////////����ȥ��ȡ����Ϣ����䵽 SubTemp�ṹ
				else if(type.equals( "usemtl"))//���µ��������ĸ�SUBSET
				{
					curSub = _info.GetSubset(parts.nextToken());//�����ǰ������subinfo
					continue;
				}				
				else if(type.equals( "f"))
				{
					//�������ʱ�� curSubӦ��Ϊ�� ��ʱʡȥ�����
					StringTokenizer[] subfaceParts = new StringTokenizer[3];
					subfaceParts[0] = new StringTokenizer(parts.nextToken(), "/");
					subfaceParts[1] = new StringTokenizer(parts.nextToken(), "/");
					subfaceParts[2] = new StringTokenizer(parts.nextToken(), "/");
					
					int vIndex[] = new int[3];
					vIndex[0] = Integer.parseInt(subfaceParts[0].nextToken())-1;
					vIndex[1] = Integer.parseInt(subfaceParts[1].nextToken())-1;
					vIndex[2] = Integer.parseInt(subfaceParts[2].nextToken())-1;
					
					int vtIndex[] = new int[3];
					if(subfaceParts[0].countTokens() == 2
							&& subfaceParts[1].countTokens() == 2
							&& subfaceParts[2].countTokens() == 2){
						curSub.hasVt = true;
						vtIndex[0] = Integer.parseInt(subfaceParts[0].nextToken())-1;
						vtIndex[1] = Integer.parseInt(subfaceParts[1].nextToken())-1;
						vtIndex[2] = Integer.parseInt(subfaceParts[2].nextToken())-1;
					}
//					curSub.hasVt = true;
//					vtIndex[0] = Integer.parseInt(subfaceParts[0].nextToken())-1;
//					vtIndex[1] = Integer.parseInt(subfaceParts[1].nextToken())-1;
//					vtIndex[2] = Integer.parseInt(subfaceParts[2].nextToken())-1;
					
					int vnIndex[] = new int[3];
					vnIndex[0] = Integer.parseInt(subfaceParts[0].nextToken())-1;
					vnIndex[1] = Integer.parseInt(subfaceParts[1].nextToken())-1;
					vnIndex[2] = Integer.parseInt(subfaceParts[2].nextToken())-1;
					
//					Vertex v0 = vertexs.get(vIndex[0]);
//					Vertex v1 = vertexs.get(vIndex[1]);
//					Vertex v2 = vertexs.get(vIndex[2]);
//					if(curSub.vertexs.contains(v0) == false){
//						curSub.vertexs.add(v0);
//					}
//					if(curSub.vertexs.contains(v1) == false){
//						curSub.vertexs.add(v1);
//					}
//					if(curSub.vertexs.contains(v2) == false){
//						curSub.vertexs.add(v2);
//					}
//					Tridata temp = new Tridata();
//					temp.v[0] = vIndex[0];
//					temp.v[1] = vIndex[1];
//					temp.v[2] = vIndex[2];
//					tridatas.add(temp);
//					curSub.tridatas.add(temp);
					
					for(int i =0; i<3; i++){
						curSub.arrV.add(arr_v.get(3*vIndex[i]+0));
						curSub.arrV.add(arr_v.get(3*vIndex[i]+1));
						curSub.arrV.add(arr_v.get(3*vIndex[i]+2));
						if(curSub.hasVt){
							curSub.arrVT.add(arr_vt.get(2*vtIndex[i]));
							curSub.arrVT.add(arr_vt.get(2*vtIndex[i]+1));
						}
//						curSub.arrVT.add(arr_vt.get(2*vtIndex[i]));
//						curSub.arrVT.add(arr_vt.get(2*vtIndex[i]+1));
						
						curSub.arrVN.add(arr_vn.get(3*vnIndex[i]));
						curSub.arrVN.add(arr_vn.get(3*vnIndex[i]+1));
						curSub.arrVN.add(arr_vn.get(3*vnIndex[i]+2));
					}//end for
					continue;
				}//"f"��ͷ�ν���
				else{
					continue;
				}
				
				
//				String[] arrStr = strTemp.split("[ ]+");//���ո�ָ�
//				if(arrStr[0].trim().equals("o"))//ȡ�ļ���
//				{
//					_info.strMeshName = arrStr[1];
//				}else if(arrStr[0].trim().equals("mtllib") )//���������ļ�
//				{
//					//��mtl�ļ�,��ʼͼƬ(ʱ����sufaceview����֮��),������subset����
//					String strMtlFilename = arrStr[1]; 
//					_info.iSubsets = SetupMaterial(resource,strMtlFilename);
//					
//				}else if(arrStr[0].trim().equals( "v"))//POS����
//				{
//					arr_v.add(Float.parseFloat(arrStr[1]));
//					arr_v.add(Float.parseFloat(arrStr[2]));
//					arr_v.add(Float.parseFloat(arrStr[3]));
//					
//					ver.add(Float.parseFloat(arrStr[1]));
//					ver.add(Float.parseFloat(arrStr[2]));
//					ver.add(Float.parseFloat(arrStr[3]));
//					vertexs.add(new Vertex(ver, k));     //�����б�
//					k++;
//					
//				}else if(arrStr[0] .trim().equals("vt"))//texcoord����
//				{
//					arr_vt.add(Float.parseFloat(arrStr[1]));
//					arr_vt.add(1.0f-Float.parseFloat(arrStr[2]));
//					
//				}else if(arrStr[0] .trim().equals( "vn"))//normal ����
//				{
//					arr_vn.add(Float.parseFloat(arrStr[1]));
//					arr_vn.add(Float.parseFloat(arrStr[2]));
//					arr_vn.add(Float.parseFloat(arrStr[3]));
//				}/////////////����ȥ��ȡ����Ϣ����䵽 SubTemp�ṹ
//				else if(arrStr[0] .trim().equals( "usemtl"))//���µ��������ĸ�SUBSET
//				{
//					curSub = _info.GetSubset(arrStr[1]);//�����ǰ������subinfo
//				}				
//				else if(arrStr[0] .trim().equals( "f"))
//				{
//					//�������ʱ�� curSubӦ��Ϊ�� ��ʱʡȥ�����
//					String[] arrVertex = null;
//					int index = -1;		
//					
//					Vertex v0 = vertexs.get(Integer.parseInt(arrStr[1].split("/")[0])-1);
//					Vertex v1 = vertexs.get(Integer.parseInt(arrStr[2].split("/")[0])-1);
//					Vertex v2 = vertexs.get(Integer.parseInt(arrStr[3].split("/")[0])-1);
//					if(curSub.vertexs.contains(v0) == false){
//						curSub.vertexs.add(v0);
//					}
//					if(curSub.vertexs.contains(v1) == false){
//						curSub.vertexs.add(v1);
//					}
//					if(curSub.vertexs.contains(v2) == false){
//						curSub.vertexs.add(v2);
//					}
////					Triangle triangle = new Triangle(v0, v1, v2);
//					
//					Tridata temp = new Tridata();
//					temp.v[0] = Integer.parseInt(arrStr[1].split("/")[0])-1;
//					temp.v[1] = Integer.parseInt(arrStr[2].split("/")[0])-1;
//					temp.v[2] = Integer.parseInt(arrStr[3].split("/")[0])-1;
//					tridatas.add(temp);
//					curSub.tridatas.add(temp);
//					
//					for(int i =1; i<=3; i++)
//					{
//						arrVertex = arrStr[i].split("/");//����� i �������Ϣ
//						index= Integer.parseInt(arrVertex[0])-1;//POS������
//						curSub.arrV.add(arr_v.get(3*index+0));
//						curSub.arrV.add(arr_v.get(3*index+1));
//						curSub.arrV.add(arr_v.get(3*index+2));
//						
//						index = Integer.parseInt(arrVertex[1])-1;//UV������
//						curSub.arrVT.add(arr_vt.get(2*index));
//						curSub.arrVT.add(arr_vt.get(2*index+1));
//						
//						
//						index = Integer.parseInt(arrVertex[2])-1;//NORMAL ������
//						curSub.arrVN.add(arr_vn.get(3*index));
//						curSub.arrVN.add(arr_vn.get(3*index+1));
//						curSub.arrVN.add(arr_vn.get(3*index+2));
////						
////						//tri.vers.add(vertexs.get(Integer.parseInt(arrVertex[i])-1));   //�����ζ�Ӧ�Ķ���
////						//vertexs.get(Integer.parseInt(arrVertex[i])-1).face.add(tri);   //�����Ӧ��������
//					}//end for		
//					//triangles.add(tri);    //���е��������б�
//					
//				}//"f"��ͷ�ν���				
			}//end while
			
//			MeshSimply _infoSimplify = new MeshSimply(vertexs, tridatas);
//			_infoSimplify.CommitSimplifyInfo();
//			for(int i = 0;i < _infoSimplify.arrData.size();i++){
//				_info.arrData.add(_infoSimplify.arrData.get(i));
//			}
			
			long endTime = Calendar.getInstance().getTimeInMillis();
			Log.d("LoadObjTime", "End time " + (endTime - startTime));
			
			//����MeshInfo���Բ������� CommitMeshInfo()���������ĵ���
			_info.CommitMeshInfo();
			
//			for(int i = 0;i < triangles.size();i++){
//				Log.d("G9Mesh", Integer.toString(triangles.get(i).vers.get(0).id));
//				Log.d("G9Mesh", Integer.toString(triangles.get(i).vers.get(1).id));
//				Log.d("G9Mesh", Integer.toString(triangles.get(i).vers.get(2).id));
//			}
			
			br.close();
		}catch (Exception e) {
			// 
			e.printStackTrace();
		}//end try
		//��ʼRENDER_TECH ��phong�������
		_info.enumRENDER_TECH = G9ENUM.RENDER_TECH_G9PHONG;
		
	}//ef constructor
	/**
	 * ��ʼ����MESH�Ĳ�����Ϣ
	 * @param resource ϵͳ��Դ
	 * @param strMtlFilename �����ļ�
	 * @return SUBSET����
	 * @throws IOException 
	 */
	private int SetupMaterial(Resources resource, String strMtlFilename) throws IOException {
		//Ka Kd Ks��ʱ����,������ subinfo��û��û����ȥ
		FileInputStream fin = new FileInputStream(sdPath + "/AR Model/" + strMtlFilename);
		InputStream ins = new BufferedInputStream(fin);
		//InputStream ins = resource.getAssets().open(strMtlFilename);
		InputStreamReader insReader = new InputStreamReader(ins);
		BufferedReader br = new BufferedReader(insReader);
		String strTemp = null;
		int iSubCount = 0;
		SubInfo curSub = null;//��ǰ��SUBSET INFO
		while((strTemp = br.readLine())!= null){
			String[] arrStr = strTemp.split("[ ]+");
			if(arrStr[0] .trim().equals( "newmtl"))//��ʾ����
			{
				//��ʱ����������ʼ
				iSubCount++;
				curSub = new SubInfo(arrStr[1]);
				_info.arrSubInfo.add(curSub);
			}else if(arrStr[0] .trim().equals( "map_Kd"))//������
			{
				//�Ӹ��ռ�
				if(curSub == null)
					break;								
				curSub.idDTex = G9Function.CreateTexture(resource,arrStr[1]);				
			}
		}//end while	
		br.close();
		return iSubCount;
	}//ef
	//------------------------------------------------����
	@Override
	public MeshInfo GetMeshInfo() {
		// ��Ҫʱ����NULL���
		return _info;
	}//ef
	public void SetRenderTech(int enumRENDER_TECH){
		_info.enumRENDER_TECH = enumRENDER_TECH;
	}//ef

	class loadVt extends Thread{
		ArrayList<Float> arr_vt = new ArrayList<Float>();//�ٴ� texcoord ����Ԫ
		Resources resources;
		String strObjName;
		
		public loadVt(Resources res,String name){
			resources = res;
			strObjName = name;
		}
		
		public void run(){
			try {
				InputStream ins = resources.getAssets().open(strObjName) ;//ֻ�ṩinputstream�ķ���
				InputStreamReader inReader = new InputStreamReader(ins);
				BufferedReader br = new BufferedReader(inReader);
				String str = null;
				long startTime = Calendar.getInstance().getTimeInMillis();
				Log.d("LoadObjTime", "Thread1 " + startTime);
				while((str = br.readLine())!= null){
					StringTokenizer parts = new StringTokenizer(str, " ");
					int numTokens = parts.countTokens();
					if (numTokens == 0)
						continue;
					String type = parts.nextToken();
					if(type.equals("vt"))//texcoord����
					{
						String s1 = parts.nextToken();
						String s2 = parts.nextToken();
//						arr_vt.add(Float.parseFloat(parts.nextToken()));
//						arr_vt.add(1.0f-Float.parseFloat(parts.nextToken()));
						arr_vt.add(Float.parseFloat(s1));
						arr_vt.add(1.0f-Float.parseFloat(s2));
						Log.d("vtPos", s1);
						Log.d("vtPos", s2);
					}
					else{
						continue;
					}
				}
				long endTime = Calendar.getInstance().getTimeInMillis();
				Log.d("LoadObjTime", "Thread1 " + (endTime - startTime));
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		
		public ArrayList<Float> getArr_vt(){
			return arr_vt;
		}
	};
	
	class loadVn extends Thread{
		ArrayList<Float> arr_vn = new ArrayList<Float>();//�ٴ� normal ����Ԫ
		BufferedReader br;
		
		public loadVn(BufferedReader b){
			br = b;
		}
		
		public void run(){
			String str = null;
			try {
				while((str = br.readLine())!= null){
					StringTokenizer parts = new StringTokenizer(str, " ");
					int numTokens = parts.countTokens();
					if (numTokens == 0)
						continue;
					String type = parts.nextToken();
					if(type.equals( "vn"))//normal ����
					{
						arr_vn.add(Float.parseFloat(parts.nextToken()));
						arr_vn.add(Float.parseFloat(parts.nextToken()));
						arr_vn.add(Float.parseFloat(parts.nextToken()));
					}
					else{
						continue;
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		
		public ArrayList<Float> getArr_vn(){
			return arr_vn;
		}
	};
	
	//------------------------------------------------����
	//------------------------------------------------����
	//------------------------------------------------test
}//EC
