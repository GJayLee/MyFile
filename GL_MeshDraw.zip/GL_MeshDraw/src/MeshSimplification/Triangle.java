package MeshSimplification;

import java.util.ArrayList;

import dana9919.gles.base.G9Function;

public class Triangle {
	public ArrayList<Vertex> vers = new ArrayList<Vertex>();
	public float[] normal;
	
	public Triangle(Vertex v0, Vertex v1, Vertex v2) {
		// TODO Auto-generated constructor stub
		vers.add(v0);
		vers.add(v1);
		vers.add(v2);
		ComputeNormal();
		for(int i = 0;i < 3;i++){
			vers.get(i).face.add(this);
			for(int j = 0;j < 3;j++){
				if(i != j && vers.get(i).neighbor.contains(vers.get(j)) == false){
					vers.get(i).neighbor.add(vers.get(j));
				}
			}
		}
		//Log.d("neighbour","-------");
	}
	
	public void ComputeNormal(){
		float[] edge1 = new float[3];
		float[] edge2 = new float[3];
		
		float v0Pos[] = new float[3];
		float v1Pos[] = new float[3];
		float v2Pos[] = new float[3];
		for(int i = 0;i < 3;i++){
			v0Pos[i] = vers.get(0).position.get(i);
			v1Pos[i] = vers.get(1).position.get(i);
			v2Pos[i] = vers.get(2).position.get(i);
		}
		
		G9Function.glV3Subtract(edge1, v1Pos, v0Pos);
		G9Function.glV3Subtract(edge2, v2Pos, v1Pos);
		normal = new float[3];
		G9Function.glV3Cross(normal, edge1, edge2);
		G9Function.glV3Normalize(normal);
	}
	
	public void ReplaceVertex(Vertex vold,Vertex vnew){
		if(vers.get(0).equals(vold)){
			vers.set(0, vnew);
		}
		else if(vers.get(1).equals(vold)){
			vers.set(1, vnew);
		}
		else{
			vers.set(2, vnew);
		}
		int i;
		vold.face.remove(this);
		if(vnew.face.contains(this) == false){
			vnew.face.add(this);
		}
		
		for(i = 0;i < 3;i++){
			//vold.RemoveIfNonNeighbor(vers.get(i));
			//vers.get(i).RemoveIfNonNeighbor(vold);
			if(vers.get(i).neighbor.contains(vold)){
				vers.get(i).neighbor.remove(vold);
			}
		}
		for(i = 0;i < 3;i++){
			for(int j = 0;j < 3;j++){
				if(i != j && vers.get(i).neighbor.contains(vers.get(j)) == false){
					vers.get(i).neighbor.add(vers.get(j));
				}
			}
		}
		ComputeNormal();
	}
	
	public boolean HasVertex(Vertex v){
		return (vers.contains(v));
	}

}
