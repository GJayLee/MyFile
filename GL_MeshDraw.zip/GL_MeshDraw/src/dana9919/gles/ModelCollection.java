package dana9919.gles;

import java.util.ArrayList;

public class ModelCollection {
	ArrayList<G9Model> _arrModel = new ArrayList<G9Model>();
	public ModelCollection() {
		// ��ʼ��
		//��ʱû��
	}//ef constructor
	public void AddModel(G9Model model){
		_arrModel.add(model);
	}//ef
	/**
	 * ȡ��ģ�Ͷ���
	 */
	public ArrayList<G9Model> GetMoelList(){
		return _arrModel;
	}//ef
}//EC
