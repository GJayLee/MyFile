package dana9919.apk.gl_meshdraw;

import java.io.File;

import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.content.res.Configuration;
import android.view.Menu;
import android.view.SurfaceView;
import android.widget.FrameLayout;


public class MainActivity extends Activity {
	MyGame0824 rview;
	public CameraScreen screen = null;
	FrameLayout frmLayout;
	FrameLayout frmLayout2;
	SurfaceView surfaceView;
	String sdPath = Environment.getExternalStorageDirectory().getPath();
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        final Window win = getWindow();
//		win.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//				WindowManager.LayoutParams.FLAG_FULLSCREEN);
//
//		// Hide the window title.
//		requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        setContentView(R.layout.ar_layout);
        
        isFolderExist(sdPath + "/AR Model/");
        
        frmLayout = (FrameLayout) findViewById(R.id.abc1);
		if (screen == null)
			screen = new CameraScreen(frmLayout.getContext());
		frmLayout.addView(screen);
		
		rview = new MyGame0824(this);
        rview.requestFocus();
        rview.setFocusableInTouchMode(true);
		frmLayout2 = (FrameLayout) findViewById(R.id.abc2);
		frmLayout2.addView(rview);
		
		//setContentView(rview);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		// TODO Auto-generated method stub
		try {   
            super.onConfigurationChanged(newConfig);   
            if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {   
                // land   
            } else if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {   
               // port   
            }   
        } catch (Exception ex) {   
      }   
	}
	
	//�ж��ļ����Ƿ���ڣ�����������򴴽�һ��
	public boolean isFolderExist(String folderPath){
		boolean result = false;
		File f = new File(folderPath);
		if(!f.exists()){
			if(f.mkdir()){
				result = true;
			}
			else
				result = false;
		}
		else
			result = true;
		
		return result;
	}
	
}
