package dana9919.apk.gl_meshdraw;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import android.content.Context;
import android.hardware.Camera;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class CameraScreen extends SurfaceView implements SurfaceHolder.Callback {
	private Camera mCamera;
	private SurfaceHolder previewHolder;
	private boolean isPreviewRunning=false;
	private Camera.AutoFocusCallback mAutoFocusCallback;
	
	private Timer mTimer;
	private TimerTask mTimerTask;
	
	//private Camera.PreviewCallback imageCaptureCallback;
	
	public CameraScreen(Context context) {
		super(context);
		// Install a SurfaceHolder.Callback so we get notified when the
		// underlying surface is created and destroyed.
		previewHolder = this.getHolder();
		previewHolder.addCallback(this);
		previewHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		
		mAutoFocusCallback = new Camera.AutoFocusCallback() {
			
			public void onAutoFocus(boolean success, Camera camera) {
				// TODO Auto-generated method stub
				if(success){
					mCamera.setOneShotPreviewCallback(null);
				}	
			}
		}; 
		
		mTimer = new Timer();
		mTimerTask = new CameraTimerTask();
		mTimer.schedule(mTimerTask, 0, 10000);
	}
	
	public void surfaceCreated(SurfaceHolder holder) {
		//************
		if(!isPreviewRunning)
			mCamera = Camera.open();
		else
			mCamera.stopPreview();
	}
	
	public void surfaceDestroyed(SurfaceHolder holder) {
		// Surface will be destroyed when we return, so stop the preview.
		// Because the CameraDevice object is not a shared resource, it's very
		// important to release it when the activity is paused.
		try {
			if (mCamera!=null) {
				//**********
				mCamera.setPreviewCallback(null);
				mCamera.stopPreview();  
				mCamera.release();
				//**********
				mCamera=null;
				isPreviewRunning=false;
			}
		} catch (Exception e) {

		}
	}

	public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
		if(mCamera!=null&&isPreviewRunning!=true)
		{
			try{
				Camera.Parameters p = mCamera.getParameters();  
				p.setPreviewSize(w, h);
				mCamera.setPreviewDisplay(holder);
				mCamera.setDisplayOrientation(90);
//				mCamera.setParameters(p);
				mCamera.setPreviewCallback(null);
				mCamera.startPreview();
				mCamera.autoFocus(mAutoFocusCallback);
			}
			catch (IOException e) {
				e.printStackTrace();
			}
			isPreviewRunning = true;
		}

	}
	
	class CameraTimerTask extends TimerTask{

		@Override
		public void run() {
			// TODO Auto-generated method stub
			if(mCamera != null)
			{
				mCamera.autoFocus(mAutoFocusCallback);
			}
			
		}
		
	}

}
